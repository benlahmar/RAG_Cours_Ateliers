# Projet Logistique intelligente — exemple fictif

## Thématiques

* Traçabilité
* Optimisation d'entrepôt
* Recommandation de services

## Partenariats

Exemple pédagogique sans partenaires réels.