# Laboratoire Systèmes numériques — exemple fictif

## Axes de recherche

Réseaux, intelligence artificielle, simulation et systèmes cyber-physiques.

## Équipes

Equipe Méthodes et Données.