# Calendrier d'admission — exemple fictif

## Dates illustratives

| Phase | Date fictive |
| --- | --- |
| Candidature | 15 janvier 2030 |
| Réponse | 20 mars 2030 |

Ces dates ne concernent aucune campagne officielle.